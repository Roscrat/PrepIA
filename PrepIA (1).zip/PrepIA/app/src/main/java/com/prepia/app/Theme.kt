package com.prepia.app

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

object Brand {
    val violet = Color(0xFF7C5CFF)
    val blue = Color(0xFF3D8BFF)
    val mint = Color(0xFF22D3A5)
    val pink = Color(0xFFFF6B9A)
    val amber = Color(0xFFFFB020)
    val orange = Color(0xFFFF8A3D)
    val red = Color(0xFFEF4444)
    val green = Color(0xFF22C55E)

    val gradient = Brush.linearGradient(listOf(violet, blue))
    val gradientWarm = Brush.linearGradient(listOf(pink, orange))
    val gradientMint = Brush.linearGradient(listOf(mint, blue))
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6A4BF5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9E4FF),
    onPrimaryContainer = Color(0xFF1E0B6B),
    secondary = Color(0xFF0FA98A),
    secondaryContainer = Color(0xFFD3F6EC),
    onSecondaryContainer = Color(0xFF00382C),
    tertiary = Color(0xFFFF6B9A),
    background = Color(0xFFF5F4FF),
    onBackground = Color(0xFF15142B),
    surface = Color.White,
    onSurface = Color(0xFF15142B),
    surfaceVariant = Color(0xFFE9E8F5),
    onSurfaceVariant = Color(0xFF5B5A73),
    outline = Color(0xFFD5D3EA),
    error = Color(0xFFD93025)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA796FF),
    onPrimary = Color(0xFF1B0B66),
    primaryContainer = Color(0xFF2B2560),
    onPrimaryContainer = Color(0xFFE5E0FF),
    secondary = Color(0xFF4FE3BE),
    secondaryContainer = Color(0xFF0F3B33),
    onSecondaryContainer = Color(0xFFBDF6E7),
    tertiary = Color(0xFFFF8FB3),
    background = Color(0xFF0D0E1F),
    onBackground = Color(0xFFEDEBFF),
    surface = Color(0xFF171833),
    onSurface = Color(0xFFEDEBFF),
    surfaceVariant = Color(0xFF242650),
    onSurfaceVariant = Color(0xFFB4B2D6),
    outline = Color(0xFF34366B),
    error = Color(0xFFFF7A70)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun PrepTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            window.navigationBarColor = scheme.surface.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = scheme, shapes = AppShapes, content = content)
}

fun scoreColor(score: Int): Color = when {
    score >= 80 -> Brand.green
    score >= 60 -> Brand.mint
    score >= 40 -> Brand.amber
    else -> Brand.red
}
