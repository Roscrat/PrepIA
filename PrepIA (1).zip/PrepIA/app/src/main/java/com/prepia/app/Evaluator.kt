package com.prepia.app

import java.text.Normalizer
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Evaluador local (funciona sin internet).
 * Puntaje = contenido técnico (65) + extensión adecuada (20) + estructura del discurso (15) - muletillas.
 *
 * Para usar un LLM real (OpenAI, Gemini, etc.) solo hay que reemplazar el cuerpo de [evaluate]
 * por una llamada a la API que devuelva un [QResult].
 */
object Evaluator {

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

    private val connectors = listOf(
        "porque", "por ejemplo", "ejemplo", "primero", "luego", "finalmente", "ademas",
        "por lo tanto", "en resumen", "entonces", "sin embargo", "ya que", "por eso"
    )
    private val fillerRegex = Regex("\\b(eh+|mm+|o sea|osea|como que|pues|digamos)\\b")

    fun evaluate(q: Question, answer: String): QResult {
        val a = norm(answer)
        val words = a.split(Regex("\\s+")).filter { it.isNotBlank() }

        if (words.size < 3) {
            return QResult(
                q.text, answer.trim(), 0, 0, 0,
                emptyList(),
                listOf("No respondiste la pregunta o la respuesta fue demasiado corta."),
                q.ideal
            )
        }

        val matched = q.keywords.filter { a.contains(it) }
        val missing = q.keywords.filterNot { a.contains(it) }
        val needed = max(2, ceil(q.keywords.size * 0.5).toInt())
        val coverage = min(1.0, matched.size.toDouble() / needed)
        val content = (coverage * 65).toInt()

        val lengthPts = when {
            words.size < 15 -> 3
            words.size < 30 -> 10
            words.size <= 180 -> 20
            else -> 14
        }
        val connCount = connectors.count { a.contains(it) }
        val connPts = min(15, connCount * 5)
        val fillers = fillerRegex.findAll(a).count()
        val penalty = min(10, fillers * 2)

        val score = (content + lengthPts + connPts - penalty).coerceIn(0, 100)
        val tech = (coverage * 100).toInt().coerceIn(0, 100)
        val clarity = (((lengthPts + connPts - penalty) * 100) / 35).coerceIn(0, 100)

        val strengths = mutableListOf<String>()
        val improvements = mutableListOf<String>()

        if (coverage >= 0.8) strengths.add("Cubriste los conceptos clave de la pregunta.")
        else if (coverage >= 0.4) strengths.add("Mencionaste algunos conceptos importantes.")
        if (words.size in 30..180) strengths.add("La extensión de tu respuesta fue adecuada.")
        if (connCount >= 2) strengths.add("Tu respuesta estuvo bien estructurada y conectada.")
        if (fillers == 0 && words.size >= 15) strengths.add("Hablaste sin muletillas.")

        if (coverage < 0.8 && missing.isNotEmpty()) {
            improvements.add("Podrías mencionar conceptos como: " + missing.take(4).joinToString(", ") + ".")
        }
        if (words.size < 30) improvements.add("Desarrolla más tu respuesta (idealmente entre 30 y 150 palabras).")
        if (words.size > 180) improvements.add("Tu respuesta fue muy larga; sé más conciso.")
        if (connCount < 2) {
            improvements.add(
                if (q.soft) "Usa el método STAR: situación, tarea, acción y resultado."
                else "Estructura tu respuesta: define, explica y da un ejemplo."
            )
        }
        if (fillers >= 2) improvements.add("Reduce las muletillas (eh, o sea, como que).")

        if (strengths.isEmpty()) strengths.add("Intentaste responder, ¡sigue practicando!")
        if (improvements.isEmpty()) improvements.add("Excelente respuesta. Intenta añadir un ejemplo real de un proyecto tuyo.")

        return QResult(q.text, answer.trim(), score, tech, clarity, strengths, improvements, q.ideal)
    }

    fun level(score: Int): String = when {
        score >= 80 -> "Excelente"
        score >= 60 -> "Bien"
        score >= 40 -> "En progreso"
        else -> "Necesitas practicar"
    }
}
