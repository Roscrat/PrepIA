@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.prepia.app

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Emoji y color de cada perfil técnico. */
fun profileEmoji(id: String): String = when (id) {
    "python" -> "🐍"
    "react" -> "⚛️"
    "flutter" -> "🦋"
    "android" -> "🤖"
    "sql" -> "🗄️"
    else -> "💻"
}

fun profileBrush(id: String): Brush = when (id) {
    "python" -> Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF22D3A5)))
    "react" -> Brush.linearGradient(listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)))
    "flutter" -> Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF6366F1)))
    "android" -> Brush.linearGradient(listOf(Color(0xFF22C55E), Color(0xFF10B981)))
    "sql" -> Brush.linearGradient(listOf(Color(0xFFFF8A3D), Color(0xFFFF6B9A)))
    else -> Brand.gradient
}

fun typeEmoji(t: String): String = when (t) {
    "Técnica" -> "🧠"
    "Blanda" -> "🤝"
    else -> "⚡"
}

/** Tarjeta base con borde suave. */
@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    border: BorderStroke? = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
    container: Color = MaterialTheme.colorScheme.surface,
    content: @Composable () -> Unit
) {
    val colors = CardDefaults.cardColors(containerColor = container)
    val elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier, colors = colors, elevation = elevation, border = border) { content() }
    } else {
        Card(modifier = modifier, colors = colors, elevation = elevation, border = border) { content() }
    }
}

/** Botón grande con degradado. */
@Composable
fun GradientButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = Icons.Filled.PlayArrow,
    brush: Brush = Brand.gradient,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .height(56.dp)
            .clip(shape)
            .alpha(if (enabled) 1f else 0.45f)
            .background(brush, shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = Color.White)
                Spacer(Modifier.size(8.dp))
            }
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

/** Círculo con emoji sobre degradado. */
@Composable
fun EmojiAvatar(emoji: String, size: Dp = 44.dp, brush: Brush = Brand.gradient) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(brush),
        contentAlignment = Alignment.Center
    ) {
        Text(emoji, fontSize = (size.value * 0.5f).sp)
    }
}

/** Anillo de puntaje animado. */
@Composable
fun ScoreRing(
    score: Int,
    size: Dp = 110.dp,
    stroke: Dp = 11.dp,
    textSize: TextUnit = 30.sp
) {
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(score) { target = score / 100f }
    val progress by animateFloatAsState(targetValue = target, animationSpec = tween(1100), label = "ring")
    val color = scoreColor(score)
    val track = MaterialTheme.colorScheme.surfaceVariant

    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(stroke / 2)) {
            val s = Stroke(width = stroke.toPx(), cap = StrokeCap.Round)
            drawArc(color = track, startAngle = -90f, sweepAngle = 360f, useCenter = false, style = s)
            drawArc(color = color, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false, style = s)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score", fontSize = textSize, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

/** Barra de métrica con porcentaje. */
@Composable
fun MetricBar(label: String, value: Int, color: Color = MaterialTheme.colorScheme.primary) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row {
            Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text("$value%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { value / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

/** Burbuja de chat. */
@Composable
fun Bubble(
    mine: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val shape = if (mine) RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
    val bg = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    Box(
        modifier = modifier
            .widthIn(max = 320.dp)
            .clip(shape)
            .background(bg, shape)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) { content() }
}

/** Tres puntos animados ("escribiendo…"). */
@Composable
fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 600, delayMillis = i * 180),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot$i"
            )
            Box(
                Modifier
                    .size(9.dp)
                    .alpha(a)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            )
        }
    }
}

/** Cabecera con degradado y esquinas inferiores redondeadas. */
@Composable
fun GradientHeader(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brand.gradient)
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) { content() }
}

/** Mini estadística sobre fondo translúcido (para usar dentro de GradientHeader). */
@Composable
fun GlassStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = modifier
    )
}

/** Pastilla pequeña de color. */
@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Contenedor que expande/contrae con animación. */
@Composable
fun ExpandableCard(
    modifier: Modifier = Modifier,
    header: @Composable () -> Unit,
    body: @Composable () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    AppCard(modifier = modifier.fillMaxWidth().animateContentSize(), onClick = { open = !open }) {
        Column(Modifier.padding(16.dp)) {
            header()
            if (open) {
                Spacer(Modifier.height(10.dp))
                body()
            }
        }
    }
}

@Composable
fun FullScreenBox(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) { content() }
}
