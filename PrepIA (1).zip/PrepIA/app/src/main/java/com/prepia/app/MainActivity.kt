package com.prepia.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifs.createChannel(this)
        setContent {
            PrepTheme {
                App()
            }
        }
    }
}

private data class NavTab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route

    val tabs = listOf(
        NavTab("home", "Inicio", Icons.Filled.Home),
        NavTab("history", "Historial", Icons.Filled.History),
        NavTab("guide", "Guía", Icons.Filled.MenuBook),
        NavTab("profile", "Perfil", Icons.Filled.Person)
    )

    Scaffold(
        bottomBar = {
            if (route in tabs.map { it.route }) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = if (vm.user != null) "home" else "auth",
            modifier = Modifier.padding(pad)
        ) {
            composable("auth") {
                AuthScreen(vm) {
                    nav.navigate("home") { popUpTo("auth") { inclusive = true } }
                }
            }
            composable("home") {
                HomeScreen(
                    vm,
                    onStart = {
                        vm.start()
                        nav.navigate("interview")
                    },
                    onAiSetup = {
                        nav.navigate("profile") {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
            composable("interview") {
                InterviewScreen(
                    vm,
                    onFinished = { id ->
                        nav.navigate("report/$id") { popUpTo("home") }
                    },
                    onExit = { nav.popBackStack() }
                )
            }
            composable(
                "report/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { e ->
                ReportScreen(vm, e.arguments?.getLong("id") ?: -1L) {
                    nav.popBackStack("home", false)
                }
            }
            composable("history") {
                HistoryScreen(vm) { id -> nav.navigate("report/$id") }
            }
            composable("guide") { GuideScreen(vm) }
            composable("profile") {
                ProfileScreen(vm) {
                    vm.logout()
                    nav.navigate("auth") { popUpTo(0) }
                }
            }
        }
    }
}
