@file:OptIn(ExperimentalMaterial3Api::class)

package com.prepia.app

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(ms: Long): String =
    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "CO")).format(Date(ms))

private fun levelEmoji(score: Int): String = when {
    score >= 80 -> "🏆"
    score >= 60 -> "👏"
    score >= 40 -> "💪"
    else -> "📚"
}

private fun profileIdByName(name: String): String =
    Bank.profiles.firstOrNull { it.name == name }?.id ?: ""

// ============================== REPORT ==============================
@Composable
fun ReportScreen(vm: AppViewModel, id: Long, onHome: () -> Unit) {
    val rec = remember(id) { vm.record(id) }
    if (rec == null) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No se encontró el reporte.")
            Spacer(Modifier.height(12.dp))
            GradientButton("Volver", icon = null, onClick = onHome)
        }
        return
    }
    val results = remember(id) { QResult.listFromJson(rec.detail) }
    val tech = if (results.isEmpty()) 0 else results.sumOf { it.tech } / results.size
    val clarity = if (results.isEmpty()) 0 else results.sumOf { it.clarity } / results.size

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GradientHeader {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Reporte de entrevista", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "${profileEmoji(profileIdByName(rec.profile))} ${rec.profile} · ${rec.type}",
                        color = Color.White.copy(alpha = 0.92f)
                    )
                    Text(fmt(rec.date), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Spacer(Modifier.height(16.dp))
                    Box(
                        Modifier.size(156.dp).clip(CircleShape).background(Color.White),
                        contentAlignment = Alignment.Center
                    ) { ScoreRing(rec.score, 136.dp, 13.dp, 46.sp) }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${levelEmoji(rec.score)} ${Evaluator.level(rec.score)}",
                        color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Text("Puntaje global sobre 100", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("Resumen")
                    Spacer(Modifier.height(8.dp))
                    MetricBar("Contenido técnico (promedio)", tech, Brand.violet)
                    MetricBar("Claridad y estructura (promedio)", clarity, Brand.mint)
                    Text(
                        "${results.size} preguntas respondidas",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
        item { SectionTitle("Detalle por pregunta", Modifier.padding(horizontal = 16.dp)) }
        items(results.withIndex().toList()) { (i, r) ->
            ExpandableCard(
                modifier = Modifier.padding(horizontal = 16.dp),
                header = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) { Text("${i + 1}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(10.dp))
                        Text(r.question, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        Pill("${r.score}", scoreColor(r.score))
                    }
                },
                body = {
                    Column {
                        Text("Tu respuesta", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(
                            if (r.answer.isBlank()) "(sin respuesta)" else r.answer,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                        )
                        FeedbackCard(r)
                    }
                }
            )
        }
        item {
            GradientButton(
                "Volver al inicio",
                icon = null,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                onClick = onHome
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ============================== HISTORY ==============================
@Composable
fun HistoryScreen(vm: AppViewModel, onOpen: (Long) -> Unit) {
    LaunchedEffect(Unit) { vm.refreshHistory() }
    val h = vm.history

    if (h.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("📈", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text("Aún no tienes entrevistas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Completa tu primera simulación y aquí verás tu evolución.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        return
    }

    val avg = h.sumOf { it.score } / h.size
    val best = h.maxOf { it.score }
    val lastScores = h.take(8).reversed()

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            GradientHeader {
                Column {
                    Text("Tu evolución", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Sigue practicando, cada entrevista cuenta 💪", color = Color.White.copy(alpha = 0.9f))
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassStat("Entrevistas", "${h.size}", Modifier.weight(1f))
                        GlassStat("Promedio", "$avg", Modifier.weight(1f))
                        GlassStat("Mejor", "$best", Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    SectionTitle("Últimos puntajes")
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().height(160.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        lastScores.forEach { rec ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${rec.score}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(3.dp))
                                Box(
                                    Modifier
                                        .width(24.dp)
                                        .height((rec.score * 1.2f).coerceAtLeast(6f).dp)
                                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(scoreColor(rec.score), scoreColor(rec.score).copy(alpha = 0.45f))
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Historial", Modifier.padding(horizontal = 16.dp)) }
        items(h) { rec ->
            val pid = profileIdByName(rec.profile)
            AppCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), onClick = { onOpen(rec.id) }) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    EmojiAvatar(profileEmoji(pid), 46.dp, profileBrush(pid))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(rec.profile, fontWeight = FontWeight.Bold)
                        Text(
                            "${rec.type} · ${fmt(rec.date)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    ScoreRing(rec.score, 54.dp, 5.dp, 15.sp)
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

// ============================== GUIDE (offline) ==============================
@Composable
fun GuideScreen(vm: AppViewModel) {
    var tab by remember { mutableStateOf(0) }
    var filter by remember { mutableStateOf("all") }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            Column {
                Text("Guía de estudio", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("📴 Disponible sin conexión", color = Color.White.copy(alpha = 0.9f))
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Conceptos", "Preguntas", "Guardadas").forEachIndexed { i, label ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
            }
        }
        when (tab) {
            0 -> ConceptList()
            1 -> {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(selected = filter == "all", onClick = { filter = "all" }, label = { Text("Todas") })
                    FilterChip(selected = filter == "soft", onClick = { filter = "soft" }, label = { Text("🤝 Blandas") })
                    Bank.profiles.forEach { p ->
                        FilterChip(
                            selected = filter == p.id,
                            onClick = { filter = p.id },
                            label = { Text("${profileEmoji(p.id)} ${p.name}") }
                        )
                    }
                }
                val list = when (filter) {
                    "all" -> Bank.all()
                    "soft" -> Bank.soft
                    else -> Bank.profileById(filter).tech
                }
                QuestionList(vm, list)
            }
            else -> QuestionList(vm, Bank.all().filter { it.id in vm.savedIds }, empty = true)
        }
    }
}

@Composable
private fun ConceptList() {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(Bank.concepts) { c ->
            ExpandableCard(
                header = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📖", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(c.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                },
                body = { Text(c.body, style = MaterialTheme.typography.bodyMedium) }
            )
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun QuestionList(vm: AppViewModel, list: List<Question>, empty: Boolean = false) {
    if (list.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🔖", fontSize = 56.sp)
            Text(
                if (empty) "Aún no guardas preguntas.\nVe a \"Preguntas\" y toca el marcador."
                else "No hay preguntas en esta categoría.",
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(list) { q ->
            val saved = q.id in vm.savedIds
            ExpandableCard(
                header = {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(q.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(top = 6.dp))
                        IconButton(onClick = { vm.toggleSaved(q.id) }) {
                            Icon(
                                if (saved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = "Guardar",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                body = {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                            .padding(12.dp)
                    ) {
                        Text("Respuesta de referencia", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(q.ideal, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            )
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

// ============================== PROFILE ==============================
@Composable
fun ProfileScreen(vm: AppViewModel, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val uri = LocalUriHandler.current
    var pendingTest by remember { mutableStateOf(false) }
    var keyInput by remember(vm.apiKey) { mutableStateOf(vm.apiKey) }
    var modelInput by remember(vm.aiModel) { mutableStateOf(vm.aiModel) }
    var showKey by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (pendingTest) vm.testNotification() else vm.setNotifications(true)
        } else {
            Toast.makeText(ctx, "Sin permiso no podemos enviar notificaciones.", Toast.LENGTH_SHORT).show()
        }
        pendingTest = false
    }

    fun ensurePermission(thenTest: Boolean) {
        if (Notifs.hasPermission(ctx)) {
            if (thenTest) vm.testNotification() else vm.setNotifications(true)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingTest = thenTest
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val h = vm.history
    val avg = if (h.isEmpty()) 0 else h.sumOf { it.score } / h.size
    val initial = (vm.user?.name?.firstOrNull() ?: 'P').uppercaseChar().toString()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Text(initial, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(10.dp))
                Text(vm.user?.name ?: "", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(vm.user?.email ?: "", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassStat("Entrevistas", "${h.size}", Modifier.weight(1f))
                    GlassStat("Promedio", "$avg", Modifier.weight(1f))
                }
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // ----- IA -----
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✨ Inteligencia artificial", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (vm.aiEnabled) Pill("Activa", Brand.green) else Pill("Sin configurar", Brand.amber)
                    }
                    Text(
                        "Con una API key de Gemini (Google AI Studio) la app evalúa tus respuestas con IA real. " +
                            "Sin key o sin internet usa la evaluación local.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp, bottom = 10.dp)
                    )
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text("API key de Gemini") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Mostrar key"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = modelInput,
                        onValueChange = { modelInput = it },
                        label = { Text("Modelo") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    GradientButton(
                        "Guardar configuración",
                        icon = null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        vm.saveAi(keyInput, modelInput)
                        Toast.makeText(ctx, "Configuración guardada", Toast.LENGTH_SHORT).show()
                    }
                    TextButton(
                        onClick = { uri.openUri("https://aistudio.google.com/apikey") },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) { Text("Conseguir una key gratis") }
                }
            }

            // ----- Notificaciones -----
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("🔔 Pregunta del día", fontWeight = FontWeight.Bold)
                            Text(
                                "Una notificación diaria para practicar rápido.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = vm.notificationsOn,
                            onCheckedChange = { on -> if (on) ensurePermission(false) else vm.setNotifications(false) }
                        )
                    }
                    OutlinedButton(onClick = { ensurePermission(true) }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Probar notificación ahora")
                    }
                }
            }

            OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Cerrar sesión") }
            Spacer(Modifier.height(8.dp))
        }
    }
}
