@file:OptIn(ExperimentalMaterial3Api::class)

package com.prepia.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
private fun cardBorder(selected: Boolean): BorderStroke =
    BorderStroke(
        if (selected) 2.dp else 1.dp,
        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
    )

// ============================== AUTH ==============================
@Composable
fun AuthScreen(vm: AppViewModel, onDone: () -> Unit) {
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(Brand.gradient)) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(88.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) { Text("🎯", fontSize = 44.sp) }
            Spacer(Modifier.height(14.dp))
            Text("PrepIA", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(
                "Practica entrevistas con IA y llega listo por ese trabajo",
                color = Color.White.copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 26.dp)
            )

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text(
                        if (register) "Crea tu cuenta" else "Bienvenido de nuevo",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(14.dp))
                    AnimatedVisibility(visible = register) {
                        Column {
                            OutlinedTextField(
                                value = name, onValueChange = { name = it }, label = { Text("Nombre") },
                                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                                singleLine = true, shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                    OutlinedTextField(
                        value = email, onValueChange = { email = it }, label = { Text("Correo") },
                        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
                        singleLine = true, shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = pass, onValueChange = { pass = it }, label = { Text("Contraseña") },
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { showPass = !showPass }) {
                                Icon(
                                    if (showPass) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Mostrar contraseña"
                                )
                            }
                        },
                        singleLine = true, shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                    error?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
                    }
                    Spacer(Modifier.height(18.dp))
                    GradientButton(
                        text = if (register) "Registrarme" else "Entrar",
                        icon = null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val err = if (register) vm.register(name, email, pass) else vm.login(email, pass)
                        if (err == null) onDone() else error = err
                    }
                    TextButton(
                        onClick = { register = !register; error = null },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(if (register) "¿Ya tienes cuenta? Inicia sesión" else "¿No tienes cuenta? Regístrate")
                    }
                }
            }
        }
    }
}

// ============================== HOME ==============================
@Composable
fun HomeScreen(vm: AppViewModel, onStart: () -> Unit, onAiSetup: () -> Unit) {
    val qd = remember { Bank.questionOfDay() }
    val h = vm.history
    val avg = if (h.isEmpty()) 0 else h.sumOf { it.score } / h.size
    val best = if (h.isEmpty()) 0 else h.maxOf { it.score }
    val profile = Bank.profileById(vm.selectedProfile)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Hola, ${vm.user?.name?.substringBefore(" ") ?: ""} 👋",
                            color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold
                        )
                        Text("¿Listo para practicar hoy?", color = Color.White.copy(alpha = 0.9f))
                    }
                    Pill(if (vm.aiEnabled) "✨ IA activa" else "📏 Modo local", Color.White)
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassStat("Entrevistas", "${h.size}", Modifier.weight(1f))
                    GlassStat("Promedio", "$avg", Modifier.weight(1f))
                    GlassStat("Mejor", "$best", Modifier.weight(1f))
                }
            }
        }

        Column(Modifier.padding(16.dp)) {
            if (!vm.aiEnabled) {
                AppCard(
                    onClick = onAiSetup,
                    container = MaterialTheme.colorScheme.primaryContainer,
                    border = null,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("✨", fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Activa la IA", fontWeight = FontWeight.Bold)
                            Text(
                                "Pega tu API key en Perfil para recibir retroalimentación inteligente.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Icon(Icons.Filled.ArrowForward, contentDescription = null)
                    }
                }
                Spacer(Modifier.height(18.dp))
            }

            SectionTitle("1. Elige tu perfil")
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Bank.profiles.forEach { p ->
                    val sel = vm.selectedProfile == p.id
                    AppCard(
                        onClick = { vm.selectedProfile = p.id },
                        border = cardBorder(sel),
                        container = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.width(150.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            EmojiAvatar(profileEmoji(p.id), 46.dp, profileBrush(p.id))
                            Spacer(Modifier.height(10.dp))
                            Text(p.name, fontWeight = FontWeight.Bold, maxLines = 2)
                            Text(
                                p.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 3
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            SectionTitle("2. Tipo de entrevista")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Bank.interviewTypes.forEach { t ->
                    val sel = vm.selectedType == t
                    AppCard(
                        onClick = { vm.selectedType = t },
                        border = cardBorder(sel),
                        container = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(typeEmoji(t), fontSize = 28.sp)
                            Text(t, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            GradientButton(
                text = "Comenzar entrevista",
                modifier = Modifier.fillMaxWidth(),
                onClick = onStart
            )
            Text(
                "5 preguntas · ${profile.name} · ${vm.selectedType}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )

            Spacer(Modifier.height(22.dp))
            AppCard(Modifier.fillMaxWidth(), container = MaterialTheme.colorScheme.secondaryContainer, border = null) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Text("💡", fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            "Pregunta del día",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            qd.text,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ============================== INTERVIEW ==============================
@Composable
fun InterviewScreen(vm: AppViewModel, onFinished: (Long) -> Unit, onExit: () -> Unit) {
    if (vm.questions.isEmpty()) {
        LaunchedEffect(Unit) { onExit() }
        return
    }

    val ctx = LocalContext.current
    val q = vm.questions[vm.index]
    var answer by remember(vm.index) { mutableStateOf("") }
    var submitted by remember(vm.index) { mutableStateOf("") }
    var feedback by remember(vm.index) { mutableStateOf<QResult?>(null) }
    var feedbackTop by remember(vm.index) { mutableStateOf(0) }
    var confirmExit by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val scroll = rememberScrollState()

    DisposableEffect(Unit) {
        val holder = arrayOfNulls<TextToSpeech>(1)
        holder[0] = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) holder[0]?.language = Locale("es", "CO")
        }
        tts = holder[0]
        onDispose {
            holder[0]?.stop()
            holder[0]?.shutdown()
        }
    }

    LaunchedEffect(feedback, feedbackTop) {
        if (feedback != null) scroll.animateScrollTo((feedbackTop - 24).coerceAtLeast(0))
    }
    LaunchedEffect(vm.evaluating) {
        if (vm.evaluating) {
            delay(120)
            scroll.animateScrollTo(scroll.maxValue)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (t != null) answer = if (answer.isBlank()) t else answer.trimEnd() + " " + t
        }
    }

    fun startSpeech() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Responde en voz alta…")
        }
        try {
            speechLauncher.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Tu dispositivo no tiene reconocimiento de voz. Escribe tu respuesta.", Toast.LENGTH_LONG).show()
        }
    }

    fun send(text: String) {
        submitted = text.ifBlank { "(sin respuesta)" }
        vm.submit(text) { feedback = it }
    }

    BackHandler { confirmExit = true }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("¿Salir de la entrevista?") },
            text = { Text("Se perderá el progreso de esta simulación.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onExit() }) { Text("Salir") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Continuar") } }
        )
    }

    val fb = feedback

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // ----- barra superior -----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { confirmExit = true }) { Icon(Icons.Filled.Close, contentDescription = "Salir") }
            Column(Modifier.weight(1f)) {
                Text(
                    "${Bank.profileById(vm.currentProfile).name} · ${vm.currentType}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Pregunta ${vm.index + 1} de ${vm.questions.size}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Pill(if (vm.aiEnabled) "✨ IA" else "📏 Local", if (vm.aiEnabled) Brand.violet else Brand.amber)
            Spacer(Modifier.width(8.dp))
        }
        LinearProgressIndicator(
            progress = { (vm.index + (if (fb != null) 1 else 0)).toFloat() / vm.questions.size },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )

        // ----- conversación -----
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scroll)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                EmojiAvatar("🤖", 38.dp)
                Spacer(Modifier.width(8.dp))
                Bubble(mine = false) {
                    Column {
                        Text(
                            "Entrevistador",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            q.text,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        TextButton(onClick = { tts?.speak(q.text, TextToSpeech.QUEUE_FLUSH, null, "q") }) {
                            Icon(Icons.Filled.VolumeUp, contentDescription = null)
                            Spacer(Modifier.size(6.dp))
                            Text("Escuchar")
                        }
                    }
                }
            }

            if (submitted.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Bubble(mine = true) {
                        Text(submitted, color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }

            if (vm.evaluating) {
                Row(verticalAlignment = Alignment.Top) {
                    EmojiAvatar("🤖", 38.dp)
                    Spacer(Modifier.width(8.dp))
                    Bubble(mine = false) {
                        Column {
                            TypingDots()
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (vm.aiEnabled) "Analizando tu respuesta con IA…" else "Analizando tu respuesta…",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (fb != null) {
                Box(
                    Modifier.onGloballyPositioned { feedbackTop = it.positionInParent().y.toInt() }
                ) { FeedbackCard(fb, vm.aiNote) }

                if (fb.followUp.isNotBlank()) {
                    Row(verticalAlignment = Alignment.Top) {
                        EmojiAvatar("🤖", 38.dp)
                        Spacer(Modifier.width(8.dp))
                        Bubble(mine = false) {
                            Column {
                                Text(
                                    "Pregunta de seguimiento",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(fb.followUp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }

        // ----- zona inferior -----
        Column(
            Modifier
                .fillMaxWidth()
                .background(
                    MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                )
                .padding(16.dp)
        ) {
            if (fb != null) {
                val last = !vm.hasNext()
                GradientButton(
                    text = if (last) "Ver reporte final" else "Siguiente pregunta",
                    icon = if (last) Icons.Filled.Check else Icons.Filled.ArrowForward,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (last) onFinished(vm.finish()) else vm.next()
                }
            } else if (vm.evaluating) {
                Text(
                    "Un momento…",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp)
                )
            } else {
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    placeholder = { Text("Escribe tu respuesta o usa el micrófono…") },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp, max = 180.dp)
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { startSpeech() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = "Hablar", tint = MaterialTheme.colorScheme.primary)
                    }
                    GradientButton(
                        text = "Enviar respuesta",
                        icon = Icons.Filled.Send,
                        enabled = answer.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) { send(answer) }
                }
                TextButton(
                    onClick = { send("") },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) { Text("Omitir pregunta") }
            }
        }
    }
}

@Composable
fun FeedbackCard(r: QResult, note: String? = null) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ScoreRing(r.score, 92.dp, 10.dp, 28.sp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(Evaluator.level(r.score), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    if (r.source == "IA") Pill("✨ Evaluado por IA", Brand.violet)
                    else Pill("📏 Evaluación local", Brand.amber)
                }
            }
            if (note != null) {
                Spacer(Modifier.height(10.dp))
                Text("⚠️ $note", style = MaterialTheme.typography.bodySmall, color = Brand.amber)
            }
            Spacer(Modifier.height(14.dp))
            MetricBar("Contenido técnico", r.tech, Brand.violet)
            MetricBar("Claridad y estructura", r.clarity, Brand.mint)
            Spacer(Modifier.height(12.dp))

            if (r.strengths.isNotEmpty()) {
                Text("✅ Lo que hiciste bien", fontWeight = FontWeight.Bold)
                r.strengths.forEach { Text("• $it", modifier = Modifier.padding(top = 2.dp)) }
                Spacer(Modifier.height(12.dp))
            }
            Text("💡 Para mejorar", fontWeight = FontWeight.Bold)
            r.improvements.forEach { Text("• $it", modifier = Modifier.padding(top = 2.dp)) }
            Spacer(Modifier.height(14.dp))

            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                    .padding(12.dp)
            ) {
                Text("📘 Respuesta de referencia", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(r.ideal, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
