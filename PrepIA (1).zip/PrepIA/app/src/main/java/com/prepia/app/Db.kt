package com.prepia.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

data class User(val id: Long, val name: String, val email: String)

data class InterviewRecord(
    val id: Long,
    val profile: String,
    val type: String,
    val score: Int,
    val date: Long,
    val detail: String
)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "prepia.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, pass TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE interviews (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, " +
                "profile TEXT NOT NULL, type TEXT NOT NULL, score INTEGER NOT NULL, date INTEGER NOT NULL, " +
                "detail TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS interviews")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Devuelve el usuario creado o null si el correo ya existe. */
    fun register(name: String, email: String, pass: String): User? {
        val cv = ContentValues().apply {
            put("name", name.trim()); put("email", email.trim().lowercase()); put("pass", hash(pass))
        }
        val id = writableDatabase.insert("users", null, cv)
        return if (id == -1L) null else User(id, name.trim(), email.trim().lowercase())
    }

    fun login(email: String, pass: String): User? {
        readableDatabase.rawQuery(
            "SELECT id, name, email FROM users WHERE email = ? AND pass = ?",
            arrayOf(email.trim().lowercase(), hash(pass))
        ).use { c ->
            return if (c.moveToFirst()) User(c.getLong(0), c.getString(1), c.getString(2)) else null
        }
    }

    fun getUser(id: Long): User? {
        readableDatabase.rawQuery("SELECT id, name, email FROM users WHERE id = ?", arrayOf(id.toString())).use { c ->
            return if (c.moveToFirst()) User(c.getLong(0), c.getString(1), c.getString(2)) else null
        }
    }

    fun saveInterview(userId: Long, profile: String, type: String, score: Int, detail: String): Long {
        val cv = ContentValues().apply {
            put("user_id", userId); put("profile", profile); put("type", type)
            put("score", score); put("date", System.currentTimeMillis()); put("detail", detail)
        }
        return writableDatabase.insert("interviews", null, cv)
    }

    fun history(userId: Long): List<InterviewRecord> {
        val out = mutableListOf<InterviewRecord>()
        readableDatabase.rawQuery(
            "SELECT id, profile, type, score, date, detail FROM interviews WHERE user_id = ? ORDER BY date DESC",
            arrayOf(userId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(InterviewRecord(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4), c.getString(5)))
            }
        }
        return out
    }

    fun interview(id: Long): InterviewRecord? {
        readableDatabase.rawQuery(
            "SELECT id, profile, type, score, date, detail FROM interviews WHERE id = ?",
            arrayOf(id.toString())
        ).use { c ->
            return if (c.moveToFirst())
                InterviewRecord(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getLong(4), c.getString(5))
            else null
        }
    }
}
