package com.prepia.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = Db(app)
    private val prefs = app.getSharedPreferences("prepia", 0)

    var user by mutableStateOf<User?>(null)
        private set
    var history by mutableStateOf<List<InterviewRecord>>(emptyList())
        private set
    var savedIds by mutableStateOf(prefs.getStringSet("saved", emptySet()) ?: emptySet())
        private set
    var notificationsOn by mutableStateOf(prefs.getBoolean("notifs", false))
        private set

    // ---------- IA ----------
    var apiKey by mutableStateOf(prefs.getString("apiKey", "") ?: "")
        private set
    var aiModel by mutableStateOf(prefs.getString("aiModel", AiClient.DEFAULT_MODEL) ?: AiClient.DEFAULT_MODEL)
        private set
    var evaluating by mutableStateOf(false)
        private set
    var aiNote by mutableStateOf<String?>(null)
        private set

    val aiEnabled: Boolean get() = apiKey.isNotBlank()

    fun saveAi(key: String, model: String) {
        apiKey = key.trim()
        aiModel = model.trim().ifBlank { AiClient.DEFAULT_MODEL }
        prefs.edit().putString("apiKey", apiKey).putString("aiModel", aiModel).apply()
    }

    // ---------- Entrevista en curso ----------
    var questions by mutableStateOf<List<Question>>(emptyList())
        private set
    var index by mutableStateOf(0)
        private set
    val results = mutableStateListOf<QResult>()
    var currentProfile by mutableStateOf("python")
        private set
    var currentType by mutableStateOf("Técnica")
        private set

    var selectedProfile by mutableStateOf("python")
    var selectedType by mutableStateOf("Técnica")

    init {
        val id = prefs.getLong("userId", -1L)
        if (id != -1L) {
            user = db.getUser(id)
            refreshHistory()
        }
    }

    // ---------- Autenticación ----------
    /** Devuelve un mensaje de error o null si todo salió bien. */
    fun login(email: String, pass: String): String? {
        if (email.isBlank() || pass.isBlank()) return "Completa todos los campos."
        val u = db.login(email, pass) ?: return "Correo o contraseña incorrectos."
        startSession(u)
        return null
    }

    fun register(name: String, email: String, pass: String): String? {
        if (name.isBlank() || email.isBlank() || pass.isBlank()) return "Completa todos los campos."
        if (!email.contains("@") || !email.contains(".")) return "Correo no válido."
        if (pass.length < 6) return "La contraseña debe tener al menos 6 caracteres."
        val u = db.register(name, email, pass) ?: return "Ese correo ya está registrado."
        startSession(u)
        return null
    }

    private fun startSession(u: User) {
        user = u
        prefs.edit().putLong("userId", u.id).apply()
        refreshHistory()
    }

    fun logout() {
        user = null
        history = emptyList()
        prefs.edit().remove("userId").apply()
    }

    // ---------- Entrevista ----------
    fun start() {
        currentProfile = selectedProfile
        currentType = selectedType
        questions = Bank.build(selectedProfile, selectedType)
        index = 0
        results.clear()
        aiNote = null
        evaluating = false
    }

    /** Evalúa con IA si hay API key y, si falla o no hay conexión, usa el evaluador local. */
    fun submit(answer: String, onDone: (QResult) -> Unit) {
        if (evaluating) return
        val q = questions[index]
        val profileName = Bank.profileById(currentProfile).name
        evaluating = true
        aiNote = null
        viewModelScope.launch {
            var r: QResult? = null
            if (aiEnabled && answer.isNotBlank()) {
                val out = AiClient.evaluate(apiKey, aiModel, profileName, currentType, q, answer)
                r = out.result
                if (r == null) aiNote = (out.error ?: "No se pudo usar la IA") + " Se usó la evaluación local."
            }
            val finalResult = r ?: Evaluator.evaluate(q, answer)
            results.add(finalResult)
            evaluating = false
            onDone(finalResult)
        }
    }

    fun hasNext(): Boolean = index < questions.size - 1

    fun next() {
        if (hasNext()) index++
        aiNote = null
    }

    /** Guarda la entrevista y devuelve el id del registro. */
    fun finish(): Long {
        val u = user ?: return -1L
        val avg = if (results.isEmpty()) 0 else results.sumOf { it.score } / results.size
        val id = db.saveInterview(
            u.id, Bank.profileById(currentProfile).name, currentType, avg, QResult.listToJson(results.toList())
        )
        refreshHistory()
        return id
    }

    fun refreshHistory() {
        val u = user ?: return
        history = db.history(u.id)
    }

    fun record(id: Long): InterviewRecord? = db.interview(id)

    // ---------- Preguntas guardadas ----------
    fun toggleSaved(id: String) {
        val s = savedIds.toMutableSet()
        if (!s.add(id)) s.remove(id)
        savedIds = s
        prefs.edit().putStringSet("saved", s).apply()
    }

    // ---------- Notificaciones ----------
    fun setNotifications(on: Boolean) {
        notificationsOn = on
        prefs.edit().putBoolean("notifs", on).apply()
        if (on) Notifs.schedule(getApplication()) else Notifs.cancel(getApplication())
    }

    fun testNotification() = Notifs.show(getApplication())
}
