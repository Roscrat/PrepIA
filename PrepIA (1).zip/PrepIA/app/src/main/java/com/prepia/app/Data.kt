package com.prepia.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Question(
    val id: String,
    val text: String,
    val keywords: List<String>,
    val ideal: String,
    val soft: Boolean = false
)

data class Profile(val id: String, val name: String, val description: String, val tech: List<Question>)

data class QResult(
    val question: String,
    val answer: String,
    val score: Int,
    val tech: Int,
    val clarity: Int,
    val strengths: List<String>,
    val improvements: List<String>,
    val ideal: String,
    val followUp: String = "",
    val source: String = "Local"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("q", question); put("a", answer); put("s", score); put("t", tech); put("c", clarity)
        put("st", JSONArray(strengths)); put("im", JSONArray(improvements)); put("i", ideal)
        put("f", followUp); put("src", source)
    }

    companion object {
        fun fromJson(o: JSONObject): QResult {
            fun list(a: JSONArray) = (0 until a.length()).map { a.getString(it) }
            return QResult(
                o.getString("q"), o.getString("a"), o.getInt("s"), o.getInt("t"), o.getInt("c"),
                list(o.getJSONArray("st")), list(o.getJSONArray("im")), o.getString("i"),
                o.optString("f", ""), o.optString("src", "Local")
            )
        }

        fun listToJson(l: List<QResult>): String = JSONArray().apply { l.forEach { put(it.toJson()) } }.toString()

        fun listFromJson(s: String): List<QResult> {
            val a = JSONArray(s)
            return (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        }
    }
}

data class Concept(val title: String, val body: String)

object Bank {
    val interviewTypes = listOf("Técnica", "Blanda", "Mixta")

    val profiles: List<Profile> = listOf(
        Profile(
            "python", "Junior Python", "Fundamentos del lenguaje, estructuras y buenas prácticas.",
            listOf(
                Question("py1", "¿Cuál es la diferencia entre una lista y una tupla en Python?",
                    listOf("mutable", "inmutable", "corchetes", "parentesis", "lista", "tupla", "modificar"),
                    "La lista es mutable (se puede modificar, usa corchetes) y la tupla es inmutable (usa paréntesis). Las tuplas son más ligeras y sirven como claves de diccionario."),
                Question("py2", "¿Qué es un diccionario y cuándo lo usarías?",
                    listOf("clave", "valor", "hash", "busqueda", "rapida", "pares", "acceso"),
                    "Es una colección de pares clave-valor con acceso rápido por clave gracias a una tabla hash. Lo uso cuando necesito buscar datos por un identificador."),
                Question("py3", "¿Qué hace un decorador en Python?",
                    listOf("funcion", "envuelve", "modifica", "comportamiento", "argumento", "sin cambiar", "@"),
                    "Es una función que recibe otra función y la envuelve para añadir comportamiento (logs, permisos, caché) sin modificar su código original."),
                Question("py4", "¿Qué es un entorno virtual y para qué sirve?",
                    listOf("venv", "dependencias", "aislar", "proyecto", "pip", "versiones", "paquetes"),
                    "Es un entorno aislado (venv) con sus propios paquetes. Evita conflictos de versiones entre proyectos y permite reproducir las dependencias con pip."),
                Question("py5", "¿Cuál es la diferencia entre == e is?",
                    listOf("igualdad", "identidad", "objeto", "memoria", "valor", "mismo"),
                    "== compara valores (igualdad) mientras que is compara identidad: si ambas variables apuntan al mismo objeto en memoria.")
            )
        ),
        Profile(
            "react", "Frontend React", "Componentes, estado, hooks y renderizado.",
            listOf(
                Question("re1", "¿Qué es el Virtual DOM y por qué React lo usa?",
                    listOf("virtual", "dom", "diferencias", "actualiza", "eficiente", "reconciliacion", "copia"),
                    "Es una representación en memoria del DOM. React compara versiones (reconciliación) y solo actualiza en el DOM real lo que cambió, lo que es más eficiente."),
                Question("re2", "¿Cuál es la diferencia entre props y state?",
                    listOf("props", "estado", "inmutable", "componente", "padre", "cambia", "render"),
                    "Las props llegan del componente padre y son de solo lectura; el state es interno del componente y cuando cambia provoca un nuevo render."),
                Question("re3", "¿Para qué sirve el hook useEffect?",
                    listOf("efecto", "secundario", "dependencias", "montaje", "ciclo", "vida", "api"),
                    "Permite ejecutar efectos secundarios (llamadas a API, suscripciones) después del render. El arreglo de dependencias controla cuándo se vuelve a ejecutar."),
                Question("re4", "¿Qué es un componente controlado?",
                    listOf("input", "estado", "valor", "onchange", "formulario", "controla"),
                    "Es un input cuyo valor lo controla el estado de React: se asigna value desde el state y se actualiza con onChange."),
                Question("re5", "¿Para qué sirven las keys al renderizar listas?",
                    listOf("key", "identificar", "elementos", "lista", "renderizado", "unico", "cambios"),
                    "Ayudan a React a identificar cada elemento de la lista de forma única para actualizar, mover o eliminar solo los que cambiaron.")
            )
        ),
        Profile(
            "flutter", "Móvil Flutter", "Widgets, estado, asincronía y persistencia.",
            listOf(
                Question("fl1", "¿Cuál es la diferencia entre StatelessWidget y StatefulWidget?",
                    listOf("estado", "cambia", "setstate", "widget", "inmutable", "redibuja"),
                    "Stateless no guarda estado y no cambia. Stateful mantiene un State que puede cambiar y se actualiza con setState, redibujando el widget."),
                Question("fl2", "¿Qué es un widget en Flutter?",
                    listOf("elemento", "interfaz", "arbol", "componer", "describe", "todo"),
                    "Es la unidad básica de la interfaz. Todo es un widget y se componen en un árbol que describe cómo se ve la pantalla."),
                Question("fl3", "¿Cómo funcionan Future, async y await?",
                    listOf("asincrono", "future", "esperar", "bloquear", "resultado", "futuro"),
                    "Un Future representa un resultado que llegará después. Con async/await espero ese resultado sin bloquear la interfaz."),
                Question("fl4", "¿Qué opciones de gestión de estado conoces en Flutter?",
                    listOf("provider", "bloc", "riverpod", "estado", "compartir", "widgets", "separar"),
                    "Provider, Riverpod y Bloc. Permiten compartir estado entre widgets y separar la lógica de la interfaz."),
                Question("fl5", "¿Cómo persistirías datos de forma local?",
                    listOf("sqlite", "shared", "preferences", "hive", "local", "almacenar", "datos"),
                    "Con shared_preferences para datos simples, o SQLite/Hive para datos estructurados, almacenándolos en el dispositivo.")
            )
        ),
        Profile(
            "android", "Móvil Android Kotlin", "Ciclo de vida, ViewModel, corrutinas y Compose.",
            listOf(
                Question("an1", "Explica el ciclo de vida de una Activity.",
                    listOf("oncreate", "onstart", "onresume", "onpause", "ondestroy", "estados"),
                    "Pasa por onCreate, onStart, onResume (visible e interactiva), onPause, onStop y onDestroy. Es clave liberar recursos en el método correcto."),
                Question("an2", "¿Por qué usar un ViewModel?",
                    listOf("sobrevive", "rotacion", "configuracion", "ui", "logica", "estado"),
                    "Guarda el estado de la UI y sobrevive a cambios de configuración como la rotación, separando la lógica de la interfaz."),
                Question("an3", "¿Qué son las corrutinas de Kotlin?",
                    listOf("suspend", "hilo", "asincrono", "scope", "dispatchers", "bloquear"),
                    "Son una forma ligera de programación asíncrona. Las funciones suspend pausan sin bloquear el hilo y se ejecutan en un scope con un dispatcher."),
                Question("an4", "¿Qué ventajas tiene Jetpack Compose frente a XML?",
                    listOf("declarativa", "composable", "estado", "recomposicion", "xml", "vistas"),
                    "Compose es declarativo: la UI es una función del estado con funciones @Composable y se actualiza por recomposición, con menos código que XML."),
                Question("an5", "¿Para qué sirve Room o SQLite en Android?",
                    listOf("base", "datos", "dao", "entity", "consulta", "local", "persistir"),
                    "Permiten persistir datos localmente. Room abstrae SQLite con entidades, DAOs y consultas verificadas en compilación.")
            )
        ),
        Profile(
            "sql", "Bases de datos SQL", "Consultas, relaciones, índices y transacciones.",
            listOf(
                Question("sq1", "¿Qué diferencia hay entre INNER JOIN y LEFT JOIN?",
                    listOf("inner", "left", "coincidencias", "nulos", "tablas", "izquierda"),
                    "INNER JOIN devuelve solo las filas con coincidencia en ambas tablas. LEFT JOIN devuelve todas las de la izquierda y NULL cuando no hay coincidencia."),
                Question("sq2", "¿Qué es una clave primaria y una foránea?",
                    listOf("primaria", "foranea", "unica", "relacion", "integridad", "tabla"),
                    "La primaria identifica de forma única cada fila. La foránea referencia la primaria de otra tabla y mantiene la integridad referencial."),
                Question("sq3", "¿Qué es un índice y cuándo conviene usarlo?",
                    listOf("indice", "busqueda", "rapida", "rendimiento", "escritura", "consulta"),
                    "Es una estructura que acelera las búsquedas por una columna. Mejora lecturas pero hace más lentas las escrituras, así que se usa en columnas muy consultadas."),
                Question("sq4", "¿Qué es la normalización?",
                    listOf("redundancia", "formas", "tablas", "dependencias", "duplicados", "integridad"),
                    "Es organizar las tablas en formas normales para eliminar redundancia y dependencias incorrectas, evitando duplicados e inconsistencias."),
                Question("sq5", "¿Qué significa ACID en transacciones?",
                    listOf("atomicidad", "consistencia", "aislamiento", "durabilidad", "commit", "rollback"),
                    "Atomicidad, Consistencia, Aislamiento y Durabilidad: una transacción se aplica completa o no se aplica (commit/rollback) y deja los datos consistentes.")
            )
        )
    )

    val soft: List<Question> = listOf(
        Question("so1", "Háblame de ti y de por qué quieres trabajar como desarrollador.",
            listOf("estudio", "experiencia", "proyecto", "habilidades", "objetivo", "semestre", "motiva", "aprender"),
            "Resume quién eres, tu formación, 1 o 2 proyectos, tus habilidades y por qué ese rol te motiva. Máximo un minuto.", true),
        Question("so2", "Cuéntame sobre un conflicto en un equipo y cómo lo resolviste.",
            listOf("situacion", "equipo", "converse", "acuerdo", "resultado", "comunicacion", "escuche", "accion"),
            "Usa el método STAR: describe la situación, tu tarea, las acciones (escuchar, dialogar, llegar a un acuerdo) y el resultado.", true),
        Question("so3", "Cuéntame de un error que hayas cometido y qué aprendiste.",
            listOf("error", "aprendi", "corregi", "equivocacion", "mejora", "responsabilidad", "solucion"),
            "Reconoce el error con honestidad, explica cómo lo corregiste y qué cambiaste para que no se repita.", true),
        Question("so4", "¿Cómo manejas la presión y los plazos de entrega?",
            listOf("priorizo", "plan", "tiempo", "organizo", "tareas", "calma", "entrega", "comunico"),
            "Planifico, priorizo tareas, divido el trabajo en partes pequeñas, mantengo la calma y comunico a tiempo si hay riesgos.", true),
        Question("so5", "¿Por qué deberíamos contratarte a ti?",
            listOf("aporto", "habilidades", "aprendo", "rapido", "equipo", "compromiso", "valor", "proyectos"),
            "Menciona tus habilidades relevantes, tu capacidad de aprender rápido, tu compromiso y el valor concreto que aportarías al equipo.", true),
        Question("so6", "¿Dónde te ves en cinco años?",
            listOf("crecer", "aprender", "senior", "liderar", "objetivos", "meta", "especializar"),
            "Habla de crecer técnicamente, asumir más responsabilidad y aportar a la empresa, de forma realista y alineada con el rol.", true)
    )

    val concepts: List<Concept> = listOf(
        Concept("Método STAR",
            "Estructura para respuestas de comportamiento: Situación (contexto), Tarea (tu responsabilidad), Acción (qué hiciste tú) y Resultado (qué logró, con datos si es posible)."),
        Concept("Cómo responder una pregunta técnica",
            "1) Define el concepto en una frase. 2) Explica cómo funciona. 3) Da un ejemplo real. 4) Menciona ventajas o limitaciones. Si no sabes algo, di cómo lo averiguarías."),
        Concept("ACID",
            "Atomicidad (todo o nada), Consistencia (datos válidos), Aislamiento (transacciones sin interferir) y Durabilidad (lo confirmado persiste)."),
        Concept("Principios SOLID",
            "Responsabilidad única, Abierto/Cerrado, Sustitución de Liskov, Segregación de interfaces e Inversión de dependencias. Buscan código mantenible y flexible."),
        Concept("Patrones de diseño comunes",
            "Singleton (una instancia), Factory (crea objetos sin acoplarse a la clase), Observer (notifica cambios), MVC/MVVM (separa interfaz, datos y lógica)."),
        Concept("Ciclo de vida en Android",
            "onCreate → onStart → onResume → onPause → onStop → onDestroy. El ViewModel conserva el estado ante rotaciones."),
        Concept("REST y HTTP",
            "REST usa verbos HTTP: GET (leer), POST (crear), PUT/PATCH (actualizar), DELETE (borrar). Los códigos 2xx indican éxito, 4xx error del cliente y 5xx error del servidor."),
        Concept("Git básico",
            "commit guarda cambios, branch crea una rama, merge la une, pull request propone cambios para revisión y rebase reordena el historial."),
        Concept("Consejos para la entrevista",
            "Respira antes de responder, piensa en voz alta, estructura tus ideas, evita muletillas (eh, o sea) y haz preguntas al final sobre el equipo y el proyecto.")
    )

    private fun allQuestions(): List<Question> = profiles.flatMap { it.tech } + soft

    fun profileById(id: String) = profiles.first { it.id == id }

    fun build(profileId: String, type: String, count: Int = 5): List<Question> {
        val tech = profileById(profileId).tech.shuffled()
        val softQs = soft.shuffled()
        return when (type) {
            "Técnica" -> tech.take(count)
            "Blanda" -> softQs.take(count)
            else -> (tech.take(3) + softQs.take(count - 3)).shuffled()
        }
    }

    fun questionOfDay(): Question {
        val all = allQuestions()
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return all[day % all.size]
    }

    fun all(): List<Question> = allQuestions()
}
