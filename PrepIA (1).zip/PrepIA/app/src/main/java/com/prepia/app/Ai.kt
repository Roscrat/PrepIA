package com.prepia.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiOutcome(val result: QResult?, val error: String?)

/**
 * Cliente de la API de Gemini (Google AI Studio). Sin librerías extra: HTTPS + JSON.
 * La API key y el modelo se configuran dentro de la app (Perfil → Inteligencia artificial).
 */
object AiClient {
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

    private const val SYSTEM = """Eres un entrevistador técnico senior de una empresa de software, exigente pero amable.
Evalúas la respuesta de un estudiante de ingeniería en una simulación de entrevista de trabajo.
Reglas:
- Responde SIEMPRE en español.
- La respuesta puede venir de dictado por voz: ignora errores de puntuación o transcripción menores.
- Evalúa el SENTIDO y la corrección de lo que dice, no solo palabras clave. Si es incorrecta, vacía o fuera de tema, el puntaje debe ser bajo.
- Para preguntas blandas (comportamiento) valora estructura STAR, ejemplos concretos y honestidad.
- Sé específico en la retroalimentación: cita lo que dijo bien y qué faltó.
- Devuelve ÚNICAMENTE un objeto JSON válido, sin texto adicional ni bloques de código, con esta forma exacta:
{"score":0-100,"tech":0-100,"clarity":0-100,"strengths":["..."],"improvements":["..."],"ideal":"respuesta modelo de 2-4 frases","followUp":"una pregunta de seguimiento natural del entrevistador"}
- score = nota global; tech = corrección y profundidad del contenido; clarity = claridad, estructura y concisión.
- strengths e improvements: entre 1 y 3 elementos cada uno, frases cortas."""

    suspend fun evaluate(
        apiKey: String,
        model: String,
        profileName: String,
        type: String,
        q: Question,
        answer: String
    ): AiOutcome = withContext(Dispatchers.IO) {
        try {
            val userText = buildString {
                append("Perfil del candidato: ").append(profileName).append("\n")
                append("Tipo de entrevista: ").append(type).append("\n")
                append("Pregunta: ").append(q.text).append("\n")
                append("Idea de respuesta esperada (guía interna, no la menciones tal cual): ").append(q.ideal).append("\n\n")
                append("Respuesta del candidato:\n").append(answer.ifBlank { "(sin respuesta)" })
            }

            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", userText)))
                    )
                )
                put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
            }

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey.trim())
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            conn.disconnect()

            if (code !in 200..299) {
                val msg = try {
                    JSONObject(text).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    "HTTP $code"
                }
                val friendly = when (code) {
                    400 -> "Solicitud rechazada (revisa la API key o el modelo): $msg"
                    401, 403 -> "API key no válida o sin permiso."
                    404 -> "El modelo \"$model\" no existe. Cámbialo en Perfil."
                    429 -> "Límite de uso de la API alcanzado. Espera un momento."
                    else -> msg
                }
                return@withContext AiOutcome(null, friendly)
            }

            val root = JSONObject(text)
            val parts = root.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
            }
            val json = extractJson(sb.toString())
            val o = JSONObject(json)

            fun list(key: String): List<String> {
                val a = o.optJSONArray(key) ?: return emptyList()
                return (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() }
            }

            val r = QResult(
                question = q.text,
                answer = answer.trim(),
                score = o.optInt("score", 0).coerceIn(0, 100),
                tech = o.optInt("tech", 0).coerceIn(0, 100),
                clarity = o.optInt("clarity", 0).coerceIn(0, 100),
                strengths = list("strengths").ifEmpty { listOf("Intentaste responder, ¡sigue practicando!") },
                improvements = list("improvements").ifEmpty { listOf("Añade un ejemplo real de un proyecto tuyo.") },
                ideal = o.optString("ideal", q.ideal).ifBlank { q.ideal },
                followUp = o.optString("followUp", ""),
                source = "IA"
            )
            AiOutcome(r, null)
        } catch (e: java.net.UnknownHostException) {
            AiOutcome(null, "Sin conexión a internet.")
        } catch (e: java.net.SocketTimeoutException) {
            AiOutcome(null, "La IA tardó demasiado en responder.")
        } catch (e: Exception) {
            AiOutcome(null, "No se pudo leer la respuesta de la IA.")
        }
    }

    /** Quita posibles ```json ... ``` y se queda con el primer objeto {...}. */
    private fun extractJson(s: String): String {
        val start = s.indexOf('{')
        val end = s.lastIndexOf('}')
        return if (start >= 0 && end > start) s.substring(start, end + 1) else s
    }
}
